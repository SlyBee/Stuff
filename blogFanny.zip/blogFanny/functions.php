<?php
// on active les menu
register_nav_menus( array(
	'topmenu' => __( 'Top menu', 'blog Fanny' )
) );


// gère le logo dans le header, parameters etc...
$args = array(
	'width' => 123,
	'height' => 69,
	'default-image' => get_template_directory_uri() . '/images/logo.png',
);
add_theme_support( 'custom-header', $args );

function theme1870wp_widgets_init() {
	
	register_sidebar( array(
		'name' => __( 'SideNav', 'blogFanny' ),
		'id'=>'sidenav',
		'description' =>__( 'Zone de widget sur le côté.', 'blog Fanny' ),
		'before_widget' =>'<aside id="%1$s" class="widget %2$s">',
		'after_widget' =>'</aside>',
		'before_title' =>'<h3 class="widget-title">',
		'after_title' => '</h3>',
	) ); 

	register_sidebar( array(
		'name' => __( 'SideNav2', 'blogFanny' ),
		'id'=>'SideNav2',
		'description' =>__( 'Zone de widget sur le côté 2.', 'blog Fanny' ),
		'before_widget' =>'<aside id="%1$s" class="widget %2$s">',
		'after_widget' =>'</aside>',
		'before_title' =>'<h3 class="widget-title">',
		'after_title' => '</h3>',
	) ); 


}
add_action( 'widgets_init', 'themeblogFanny_widgets_init' );