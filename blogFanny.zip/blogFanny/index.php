<?php get_header();?>


<section id="mainContainer">
 	<header class="header">
	    <div class="headerContent">
	    	<div id="logo">
	    		<?php if ( get_header_image() ) : ?>
				<a id="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"
				rel="home">
				<img src="<?php header_image(); ?>" width="<?php echo
				get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height;
				?>" alt="<?php bloginfo( 'name' ) ?>">
			<?php endif; ?>
	    	</div>
	    	<div>
	<?php if ( has_nav_menu('topmenu') ) : ?>
		<nav role="navigation" id="mainNav">
			<?php wp_nav_menu( array( 'theme_location' => 'topmenu' ) ); ?>
		</nav>
	<?php endif; ?>
	    	</div>
	    	<aside id="headerAside">
			<a href=""><span class="glyphicon glyphicon-search" aria-hidden="true"></span></a>
			<a href=""><span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span></a>
	    	</aside>
	    </div>
	</header>
	        <aside id="sideNav">
        	<div id="sideWrapper">
        	<div id="picWrapper">
        		<img src="<?php echo get_bloginfo('template_directory');?>/images//coeur.png" >
        	</div>
	        	<?php if (is_active_sidebar( 'SideNav' )) : ?>
					<div id="sideWrapper">
						<div class="categoriesList">
							<?php dynamic_sidebar( 'Slideshow' ); ?>
						</div>
					</div>
				<?php endif; ?>	
        	</div>
			<a  id ="newsletterLink" href="">Newsletter</a>
        </aside>


        <section id="content">
        	<div class="articleWrapper">
        		<?php if ( have_posts() ) : ?>
					<?php /* Start the Loop */ ?>
					<?php while ( have_posts() ) : the_post(); ?>
						<article class="article-<?php the_ID(); ?>" <?php post_class(); ?>>

							<header>
								<?php if ( is_single() ) : the_title( '<h2 class="entry-title">', '</h2>' );
									else : the_title( '<h2 class="entry-title"><a href="' 
												. esc_url( get_permalink() ) 
												. '" rel="bookmark">','</a></h2>' );

									endif;?>

							</header>
							<?php the_content(); ?>
							<p>Date de parution: <?php the_date('d-m-Y', '<p>', '</p>'); ?></p>
						</article>
					<?php endwhile; ?>
				<?php endif; ?>
        	</div>
        </section>
        <div class="clearfix"></div>
    	<footer id="footerwrap">
			<div id="footer">
				<div id="footerContent">
					<p><?php dynamic_sidebar('footer' ); ?></p>
				</div>
			</div>
				<?php get_footer(); ?>
		</footer>

</section>
	

